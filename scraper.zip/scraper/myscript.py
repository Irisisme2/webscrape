import requests
from bs4 import BeautifulSoup
import sqlite3
import time

def fetch_data(url):
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'}
    response = requests.get(url, headers=headers)
    
    if response.status_code == 200:
        return response.text
    else:
        print(f"Błąd {response.status_code} podczas pobierania danych z {url}")
        return None

def get_books_list(url):
    html_data = fetch_data(url)
    
    if html_data:
        soup = BeautifulSoup(html_data, 'html.parser')

        # Find all product containers on the page
        product_containers = soup.find_all('h3')

        # Extract the book names from the containers
        book_list = [container.a.attrs['title'] for container in product_containers]

        return book_list

    return None

def get_books_by_genre(url, genre):
    html_data = fetch_data(url)
    
    if html_data:
        soup = BeautifulSoup(html_data, 'html.parser')

        # Find all product containers on the page
        product_containers = soup.find_all('h3')

        # Filter product containers by genre
        genre_books = [container.a.attrs['title'] for container in product_containers if genre.lower() in container.a.attrs['title'].lower()]

        return genre_books

    return None

def get_book_details(url, book_title):
    html_data = fetch_data(url)
    
    if html_data:
        soup = BeautifulSoup(html_data, 'html.parser')

        # Find the container for the specified book
        book_container = soup.find('h3', {'title': book_title})

        if book_container:
            # Extract details for the specified book
            book_price = book_container.find_next('p', class_='price_color').text.strip()
            availability = book_container.find_next('p', class_='instock availability').text.strip()

            return {
                'title': book_title,
                'price': book_price,
                'availability': availability
            }

    return None

def get_books_count(url):
    html_data = fetch_data(url)
    
    if html_data:
        soup = BeautifulSoup(html_data, 'html.parser')

        # Find the count information on the page
        count_info = soup.find('div', class_='col-sm-8 h1').text.strip()

        return count_info

    return None

def save_books_to_database(book_list):
    connection = sqlite3.connect('prices.db')
    cursor = connection.cursor()

    cursor.execute('''CREATE TABLE IF NOT EXISTS books
                      (id INTEGER PRIMARY KEY AUTOINCREMENT,
                       title TEXT,
                       price TEXT,
                       availability TEXT)''')

    for book_title in book_list:
        book_details = get_book_details('https://books.toscrape.com/', book_title)

        if book_details:
            cursor.execute("INSERT INTO books (title, price, availability) VALUES (?, ?, ?)",
                           (book_details['title'], book_details['price'], book_details['availability']))

    connection.commit()
    connection.close()

def display_all_books():
    connection = sqlite3.connect('prices.db')
    cursor = connection.cursor()

    cursor.execute("SELECT * FROM books")
    books = cursor.fetchall()

    if books:
        print("All Books in the Database:")
        for book in books:
            print(f"ID: {book[0]}, Title: {book[1]}, Price: {book[2]}, Availability: {book[3]}")
    else:
        print("No books found in the database.")

    connection.close()

def main():
    base_url = 'https://books.toscrape.com/'

    # Get the list of all books on the page
    books_list = get_books_list(base_url)
    print("List of all books:", books_list)

    # Get the list of books for a specific genre
    genre = 'Science Fiction'
    genre_books = get_books_by_genre(base_url, genre)
    print(f"List of books in the genre '{genre}':", genre_books)

    # Get details for a specific book
    book_title = 'Sapiens: A Brief History of Humankind'
    book_details = get_book_details(base_url, book_title)
    print(f"Details for the book '{book_title}':", book_details)

    # Get the total count of books on the page
    books_count = get_books_count(base_url)
    print("Total count of books:", books_count)

    # Save all books to the database
    save_books_to_database(books_list)

    # Display all books in the database
    display_all_books()

    # Add this line to pause the script for 5 seconds
    time.sleep(5)

if __name__ == "__main__":
    main()
